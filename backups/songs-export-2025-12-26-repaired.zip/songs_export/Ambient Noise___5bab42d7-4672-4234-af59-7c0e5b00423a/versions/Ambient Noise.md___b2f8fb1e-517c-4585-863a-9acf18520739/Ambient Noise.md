# Ambient Noise

The group stands/sits in a circle, often wildly mixed up. One person starts to make a rhythmic noise, like singing a few notes, clapping, flicking, whatever comes to mind. The next person enters with a new sound. This goes on and on until a nice rhythmic backdrop is created.