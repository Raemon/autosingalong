#  Always Look on the Bright Side

## By Monty Python

A silly song about making the best of terrible things

We generally opens with this one. It has the advantage that everyone knows it. It also foreshadows all the dark elements of the Solstice while being bright and silly itself.

You can watch [the original
video](https://www.youtube.com/watch?v=jHPOzQzk9Qo) for a sense of the
idea and the sound.