#  Bitter Wind Blown

## By Raymond Arnold
## A lullaby for a child that is shivering in the cold

This song takes on the "winter" concept most directly: the cold and
darkness and *danger* for the unprepared.

In some places, it is referred to as "Bitter Wind Lullaby" to distinguish it
from the later [Bitter Wind March](../../Bitter_Wind_March/gen/)

This song is available for sale via bandcamp in [all three albums](https://humanistculture.bandcamp.com/).

[A recording of this from the 2020 North American Distributed Chorus](https://www.jefftk.com/solstice-2020/01-bitter-wind-blown--2020-12-20-011646.mp3) is available.

A [Bayesian Choir Performance](https://www.youtube.com/watch?v=VNIaA5WJaHE) of this song was on Youtube, and still probably exists somewhere.
