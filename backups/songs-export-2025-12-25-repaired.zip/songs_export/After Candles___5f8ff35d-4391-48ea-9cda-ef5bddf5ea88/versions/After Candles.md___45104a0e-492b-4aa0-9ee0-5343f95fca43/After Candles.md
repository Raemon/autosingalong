# After Candles
## By Matt Elder

We face dire challenges -- some ancient, some new -- that do not yet have simple solutions. What do we do? Part of the answer, today, is just as when humanity was young: we band together. We find comfort, together. We work and think and explore, together.

We are shaped to need other humans. We need each other to thrive. And the more profound the stakes for which we strive, the more we must rely upon each other to help us face the darkness.