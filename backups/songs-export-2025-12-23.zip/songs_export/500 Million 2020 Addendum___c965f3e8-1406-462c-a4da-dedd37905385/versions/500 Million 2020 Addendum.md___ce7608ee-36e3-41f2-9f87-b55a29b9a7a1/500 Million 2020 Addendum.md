# 500 Million: 2020 Addendum
## By Maia Werbos

[Note: this speech is no longer endorsed by its author due to obvious failure of
prediction.]

There’s one more thing to add this year.

Globally, as of this week, about 1.6 million people have died of COVID-19.

Within months after COVID claimed its first victim, we sequenced its genome.
Within weeks of that, we developed vaccines using brand-new, extraordinarily
powerful biological technology. Within one year, we began a worldwide campaign
to deploy it to every corner of the Earth, erasing this disease once and for
all.

If three times as many people die of the novel coronavirus next year, it will
still be just over 1% of the death toll that smallpox took on humanity before it
was extinguished forever.

You are a member of the species that did that. Never forget what we are capable
of, when we band together and declare battle on what is broken in the world.

Never forget that you are part of the species that will destroy SaRS-Cov2.