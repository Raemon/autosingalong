# Bridge over Troubled Water
## By Paul Simon and Art Garfunkel
## A promise of support

An outside song. [Original recording with lyrics](https://www.youtube.com/watch?v=H_a46WJ1viA)