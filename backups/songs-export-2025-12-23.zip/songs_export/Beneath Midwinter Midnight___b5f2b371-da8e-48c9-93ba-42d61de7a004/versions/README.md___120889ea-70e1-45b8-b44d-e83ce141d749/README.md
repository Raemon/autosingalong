# Beneath Midwinter Midnight
## By Raymond Arnold
## A lament of winter, contrasting with repeated "we are not alone"s

This song is available for sale via bandcamp in the [2014](https://humanistculture.bandcamp.com/album/solstice-2014) album.

The original 2014 version (recorded on bandcamp) is a capella with call-and-response for every line.  The 2023 version (the sheet music) has sparse chords for a guitar, goes well with cello, and does not use call-and-response.  It's a flexible song, that way.