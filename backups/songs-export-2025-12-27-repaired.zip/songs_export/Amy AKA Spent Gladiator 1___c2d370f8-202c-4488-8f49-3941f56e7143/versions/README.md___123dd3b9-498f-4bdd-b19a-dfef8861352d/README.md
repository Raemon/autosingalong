# Amy AKA Spent Gladiator 1
## By The Mountain Goats

This is an outside song, available [on
youtube](https://www.youtube.com/watch?v=7sNakKm3Pr0) or [as
lyrics](https://genius.com/The-mountain-goats-amy-aka-spent-gladiator-1-lyrics).